package com.qb.app.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.VBox;

public class CashierRefundController implements Initializable {

    @FXML
    private VBox refundItemContainer;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
